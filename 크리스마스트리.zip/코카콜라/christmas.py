from PIL import Image
print("Pillow is installed and working!")
tree = {1 : 'triangle.png'}
deco = {1 : 'glass_circle.png', 2 : 'star.png', 3 : 'gift_box.png', 4 : 'bell.png'}
light = {1 : 'yello.png', 2 : 'green.png', 3 : 'blue.png', 4 : 'purple.png', 5 : 'all_color.png'}
side_doll = {1 : 'snowman.png', 2 : 'santa.png', 3 : 'rudolph.png'}
list_up = []
for i in range(4):
    list_up.append(int(input('트리 -> 데코 -> 조명 -> 사이드 인형 순대로 원하시는 장식의 번호를 입력하세요.')))
tree_images = Image.open(tree[list_up[0]])
deco_images = Image.open(deco[list_up[1]])
light_images = Image.open(light[list_up[2]])
side_doll_images = Image.open(side_doll[list_up[3]])

tree_images = tree_images.convert("RGBA")
deco_images = deco_images.convert("RGBA")
light_images = light_images.convert("RGBA")
side_doll_images = side_doll_images.convert("RGBA")

tree_size = 100
deco_size = 100  # 데코 사이즈 줄이기
light_size = 100
side_doll_size = 100

deco_images = deco_images.resize((deco_size, deco_size))
light_images = light_images.resize((light_size, light_size))
side_doll_images = side_doll_images.resize((side_doll_size, side_doll_size))

output = tree_images.copy()
output.paste(deco_images, (output.width // 2 - deco_images.width // 2, 0), deco_images)  # 트리 위쪽
output.paste(light_images, (output.width // 2 - light_images.width // 2, output.height // 2 - light_images.height // 2), light_images)  # 트리 가운데
output.paste(side_doll_images, (output.width - side_doll_images.width - 10, output.height - side_doll_images.height - 10), side_doll_images)  # 트리 완전 아래쪽

output.show()
output.save('final_tree.png')
print(f'트리모양 : {tree[list_up[0]]}, 데코장식 : {deco[list_up[1]]}, 조명색상 : {light[list_up[2]]}, 사이드 인형 : {side_doll[list_up[3]]}')
print("선택하신 옵션으로 트리를 만들었습니다. 'final_tree.png'를 확인하세요!")